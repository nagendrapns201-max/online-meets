# SecureMeet AI — System Architecture (Phase 0)

## 1. High-Level Overview

SecureMeet AI is a monorepo with two deployable applications and one media layer:

```
                         ┌─────────────────────┐
                         │      Nginx           │
                         │  (TLS termination,    │
                         │   reverse proxy)       │
                         └──────────┬───────────┘
                    ┌───────────────┼───────────────────┐
                    │               │                   │
             ┌──────▼──────┐ ┌──────▼───────┐   ┌───────▼────────┐
             │  Frontend    │ │   Backend     │   │  LiveKit SFU    │
             │  Next.js     │ │   NestJS API  │   │  (media server) │
             │  (SSR/CSR)   │ │   + Socket.IO │   │  WebRTC signal- │
             └──────┬───────┘ └──────┬────────┘   │  ing/ TURN/STUN │
                    │                │             └────────┬────────┘
                    │         ┌──────┴───────┐               │
                    │         │              │               │
             ┌──────▼──┐ ┌────▼─────┐ ┌──────▼─────┐         │
             │ Browser  │ │PostgreSQL│ │   Redis     │◄────────┘
             │ WebRTC   │ │(Prisma)  │ │(sessions,   │
             │ client   │ └──────────┘ │pub/sub,     │
             └──────────┘              │rate limits) │
                                        └─────────────┘
                    │
             ┌──────▼───────┐
             │ S3 / R2      │
             │ (recordings, │
             │  avatars)    │
             └──────────────┘
```

## 2. Why LiveKit over raw mediasoup

For a production build, **LiveKit** is the recommended SFU: it ships a managed signaling protocol, room/participant permission model, recording egress, and server SDKs — which maps directly onto your host/co-host/participant roles and "invitation-only" access requirement. Raw mediasoup is more flexible but means building signaling, room state, and reconnection logic from scratch. We'll build the NestJS backend so the SFU is abstracted behind a `MediaService` interface — LiveKit first, swappable later if needed.

## 3. Core Modules (Backend, NestJS)

- `auth` — JWT, refresh tokens, OAuth (Google/Microsoft), email OTP, MFA (TOTP)
- `users` — profiles, org membership, device sessions
- `organizations` — org admin, member directory (source of truth for Employee/Student/User IDs)
- `meetings` — create/schedule/recurring meetings, passwords, lock state
- `invitations` — the authorization gate (see §5)
- `media` — LiveKit token issuance, room lifecycle, recording control
- `chat` — Socket.IO gateway, persisted messages
- `whiteboard` — Socket.IO gateway, CRDT-based state (Yjs)
- `polls` — creation, voting, results
- `breakout-rooms` — sub-room orchestration via LiveKit
- `ai-insights` — consent-gated engagement signal ingestion + aggregation
- `analytics` — dashboards, exports
- `notifications` — email/push
- `audit-log` — security-relevant event trail
- `common` — guards, interceptors, filters, pipes (shared)

## 4. Core Modules (Frontend, Next.js)

- `app/(auth)` — login, register, MFA, OAuth callback
- `app/(dashboard)` — org admin & host dashboards
- `app/meeting/[id]` — the in-call experience (WebRTC via LiveKit client SDK)
- `components/meeting/*` — video grid, controls, chat panel, whiteboard, polls
- `store/` — Redux Toolkit slices (auth, meeting, ui)
- `lib/` — API client (React Query), LiveKit client wrapper, socket client

## 5. Invitation-Only Access — Authorization Flow

This is the requirement that most differentiates this build from a generic Zoom clone, so it's a first-class flow, not an add-on:

```
1. User clicks meeting link  →  frontend hits GET /meetings/:id/access-check
2. Backend AuthGuard verifies JWT (must be logged in — no anonymous join)
3. InvitationGuard checks: does an Invitation row exist for
   (meetingId, userId) OR (meetingId, matched email/employeeId/studentId)?
4. If meeting.orgRestricted → verify user.organizationId === meeting.organizationId
5. If meeting.hasPassword → verify password (only after invitation check passes)
6. All pass → issue short-lived LiveKit room token scoped to that user's role
7. Any failure at any step → 403 "Access Denied", audit-logged, no token issued
```

Knowing the meeting link/ID never bypasses step 3. This is enforced server-side only — the frontend never trusts client state for this decision.

## 6. Data Flow: Real-Time Signaling

- WebRTC media (audio/video/screen-share) → **LiveKit SFU**, not through our NestJS server (avoids overloading the API server with media).
- Chat, whiteboard, polls, hand-raise, presence → **Socket.IO gateway** on NestJS, backed by Redis adapter for horizontal scaling.
- AI engagement signals → computed **client-side** (face detection via a browser ML model), only aggregate/derived signals sent to backend — raw video never leaves the browser for this feature.

## 7. Deployment Topology

- Frontend: containerized Next.js, deployed behind Nginx, scaled horizontally
- Backend: containerized NestJS, stateless (sessions in Redis), scaled horizontally
- Socket.IO: Redis adapter required once >1 backend replica exists
- LiveKit: self-hosted via their official Helm chart or Docker, or LiveKit Cloud
- PostgreSQL: managed (RDS/Cloud SQL) in production; local container in dev
- Redis: managed (ElastiCache) in production; local container in dev
- Object storage: S3 or Cloudflare R2 for recordings/avatars

## 8. Phased Build Order (matches project roadmap)

0. Architecture + scaffold *(this doc)*
1. Prisma schema + PostgreSQL
2. Auth module
3. Meetings + Invitations + LiveKit integration (the access-control core)
4. Real-time features (chat/whiteboard/polls/breakout)
5. AI engagement signals
6. Dashboards (host/participant UI)
7. Security hardening pass
8. Test suites
9. DevOps (Docker/K8s/CI-CD/Nginx)
10. Full documentation set
