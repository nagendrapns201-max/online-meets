# Database Schema — Phase 1

Full schema: `backend/prisma/schema.prisma`

## Entity Relationship Diagram

```mermaid
erDiagram
    Organization ||--o{ User : "employs/enrolls"
    Organization ||--o{ Meeting : "restricts"

    User ||--o{ RefreshToken : has
    User ||--o{ Device : owns
    User ||--o{ OtpCode : receives
    User ||--o{ Meeting : hosts
    User ||--o{ MeetingParticipant : "joins as"
    User ||--o{ Invitation : "invited by"
    User ||--o{ Invitation : "invited (if account exists)"
    User ||--o{ ChatMessage : sends
    User ||--o{ Poll : creates
    User ||--o{ PollVote : casts
    User ||--o{ AuditLog : triggers
    User ||--o{ EngagementSample : "generates (consented)"

    Meeting ||--o{ Invitation : gates
    Meeting ||--o{ MeetingParticipant : has
    Meeting ||--o{ Recording : produces
    Meeting ||--o{ ChatMessage : contains
    Meeting ||--o{ Poll : hosts
    Meeting ||--o{ BreakoutRoom : spawns
    Meeting ||--o{ EngagementSample : collects
    Meeting ||--o{ Meeting : "recurs as"

    Poll ||--o{ PollOption : has
    PollOption ||--o{ PollVote : receives
```

## Key Design Decisions

**Invitation is the authorization source of truth.** The `Invitation` model can
reference either a known `User.id` (existing account) or a raw identifier
(`EMAIL` / `USER_ID` / `EMPLOYEE_ID` / `STUDENT_ID`) for people invited before
they've registered. The `@@unique([meetingId, identifierType, identifierValue])`
constraint prevents duplicate invites and gives the `InvitationGuard`
(Phase 3) a single indexed lookup to check on join.

**`MeetingParticipant` vs `Invitation` are deliberately separate.** Invitation
= permission to join. MeetingParticipant = an actual session record (join
time, leave time, speaking duration, camera/mic state) — this is what feeds
the host dashboard. A user can be invited and never join (no
MeetingParticipant row), or — for recurring meetings — join multiple
instances.

**Recurring meetings** use a self-relation (`parentMeetingId` →
`recurringInstances`). The parent holds the recurrence rule
(`recurrenceFrequency`, `recurrenceUntil`); each generated occurrence is a
full `Meeting` row so it can have its own invitations, participants, and
recordings.

**Refresh tokens are hashed, not stored raw**, and linked to `Device` so a
user can revoke a single device's session (device management requirement)
without logging out everywhere.

**`EngagementSample` never stores raw video/audio** — only derived booleans
and a focus-score integer, and only when `consentGiven = true`. This keeps
the AI feature's data footprint minimal and matches the "not a definitive
measure" framing from the spec — the field is explicitly a percentage
estimate, not a verdict.

**`AuditLog.metadata` is a JSON column** so different `AuditAction` types
(login failures, host transfers, participant removal, etc.) can carry
different structured detail without schema churn.

## Indexes & Constraints Summary

| Model | Notable indexes/constraints |
|---|---|
| `User` | unique `email`, unique `googleId`/`microsoftId`, indexed `employeeId`/`studentId` for invitation matching |
| `Invitation` | unique `(meetingId, identifierType, identifierValue)`, indexed `(identifierType, identifierValue)` |
| `Meeting` | unique `meetingCode`, unique `livekitRoomName`, indexed `status`, `hostId`, `organizationId` |
| `MeetingParticipant` | unique `(meetingId, userId)` — one session record per user per meeting |
| `PollVote` | unique `(optionId, userId)` — prevents double-voting |
| `RefreshToken` | unique `tokenHash`, indexed `expiresAt` for cleanup jobs |

## Running It

```bash
cd backend
cp .env.example .env      # if not already done
# make sure infra/docker/docker-compose.dev.yml is up (postgres running)
npx prisma migrate dev --name init
npx prisma generate
npx prisma studio          # optional: browse the DB visually
```
