# SecureMeet AI

Secure, browser-only, invitation-only video meeting platform. See `docs/ARCHITECTURE.md` for the full system design.

## Monorepo Layout

```
securemeet-ai/
├── backend/          NestJS API, Socket.IO gateways, Prisma
│   ├── src/
│   │   ├── modules/  feature modules (auth, meetings, invitations, ...)
│   │   ├── common/   guards, filters, interceptors, pipes
│   │   └── config/   env/config loading
│   └── prisma/        schema.prisma, migrations
├── frontend/          Next.js app
│   └── src/
│       ├── app/       routes (App Router)
│       ├── components/
│       ├── store/     Redux Toolkit slices
│       ├── lib/       API client, socket client, LiveKit wrapper
│       └── hooks/
├── infra/
│   ├── docker/         docker-compose files
│   ├── k8s/             Kubernetes manifests (added in DevOps phase)
│   └── nginx/            reverse proxy config (added in DevOps phase)
└── docs/                architecture, SRS, API docs, guides
```

## Phase 0 Setup (this step)

Prerequisites: Node.js 20+, Docker, npm.

```bash
# 1. Start local infra (Postgres, Redis, LiveKit dev server)
cd infra/docker
docker compose -f docker-compose.dev.yml up -d

# 2. Backend
cd ../../backend
cp .env.example .env
npm install
# (Prisma schema arrives in Phase 1 — nothing to migrate yet)

# 3. Frontend
cd ../frontend
cp .env.example .env
npm install
npm run dev   # http://localhost:3000
```

At this point you have empty NestJS/Next.js projects wired to real infrastructure,
but no application code yet — that starts in Phase 1 (database schema) and
Phase 2 (auth), etc., per `docs/ARCHITECTURE.md` §8.

## Build Phases

0. ✅ Architecture + scaffold
1. ⬜ Database schema (Prisma/PostgreSQL)
2. ⬜ Auth (JWT, refresh, OAuth, MFA, OTP)
3. ⬜ Meetings + Invitations + LiveKit integration
4. ⬜ Real-time features (chat/whiteboard/polls/breakout rooms)
5. ⬜ AI engagement signals (consent-gated)
6. ⬜ Host/Participant dashboards
7. ⬜ Security hardening
8. ⬜ Testing
9. ⬜ DevOps (Docker/K8s/CI-CD/Nginx)
10. ⬜ Documentation set
